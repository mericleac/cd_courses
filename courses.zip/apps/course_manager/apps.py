from django.apps import AppConfig


class CourseManagerConfig(AppConfig):
    name = 'course_manager'
